import jwt
import datetime
import hashlib
from flask import Flask, render_template, jsonify, request
from datetime import datetime, timedelta

SECRET_KEY = 'SPARTA'

app = Flask(__name__)

# Mongo DB 연결
from pymongo import MongoClient
# client = MongoClient('내AWS아이피', 27017, username="아이디", password="비밀번호")
client = MongoClient('localhost', 27017)
db = client.dbsparta_plus_week3

## HTML을 주는 부분을 꼭 해야 한다.
@app.route('/')
def home():
   return render_template('main.html')

## HTML을 주는 부분을 꼭 해야 한다.
@app.route('/join')
def join():
    return render_template('join.html')

## HTML을 주는 부분을 꼭 해야 한다.
@app.route('/review')
def review():
    return render_template('review.html')

## 닉네임 중복확인
@app.route('/api/nameCheck', methods=["POST"])
def name_Check():
    m_name_receive = request.form['m_name_give']
    exists = bool(db.member_info.find_one({"m_name":m_name_receive}))
    return jsonify({'result':'success', 'exists':exists})

## 아이디 중복확인
@app.route('/api/idCheck', methods=['POST'])
def id_Check():
    m_id_receive = request.form['m_id_give']
    exists = bool(db.member_info.find_one({"m_id": m_id_receive}))
    return jsonify({'result': 'success', 'exists': exists})

## 회원가입
@app.route('/api/join', methods=['POST'])
def member_join():
    m_name_receive = request.form['m_name_give']
    m_id_receive = request.form['m_id_give']
    m_pw_receive = request.form['m_pw_give']
    password_hash = hashlib.sha256(m_pw_receive.encode('utf-8')).hexdigest()
    doc = {
        "m_name" : m_id_receive,   # 닉네임
        "m_id": m_name_receive,    # 아이디
        "m_pw": password_hash,     # 비밀번호
    }
    db.member_info.insert_one(doc)
    return jsonify({'result': 'success'})

## 로그인
@app.route('/api/login', methods=['POST'])
def login():
    m_id_receive = request.form['m_id_give']
    m_pw_receive = request.form['m_pw_give']

    pw_hash = hashlib.sha256(m_pw_receive.encode('utf-8')).hexdigest()
    result = db.member_info.find_one({'m_id': m_id_receive, 'm_pw': pw_hash})

    if result is not None:
        payload = {
         'id': m_id_receive,
         'exp': datetime.utcnow() + timedelta(seconds=60 * 60 * 24)  # 로그인 24시간 유지
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm='HS256').decode('utf-8')
        # jwt 토큰은 놀이공원 자유이용권 같은 거

        return jsonify({'result': 'success', 'token': token})
    # 찾지 못하면
    else:
        return jsonify({'result': 'fail', 'msg': '아이디/비밀번호가 일치하지 않습니다.'})

if __name__ == '__main__':
   app.run('0.0.0.0',port=5000,debug=True)